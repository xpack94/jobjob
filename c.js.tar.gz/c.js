$(function(){

    var jeu={

        lignes:4,
        colonnes:4,
        url:'img.png',
        tdWidth:125,
        tdHeight:125,
        couleurImageVide:"grey",
        taille:0,
        nbrTour:300,
        init:function(){
            this.createGrid();

        },



        createGrid:function(){



          ordreDesCase=0;
          let table=$("<table></table>");
          for(let i=0;i<this.lignes;i++){
              let tr=$("<tr></tr>");
              for(let j=0;j<this.colonnes;j++){
                let td=$("<td></td>");
                let span=$("<span></span>");
                //verifier que ce n'est pas la derniere case ou se trouve l'image vide
                if(i*j!=(this.lignes-1)*(this.colonnes-1)){
                    td.addClass(`td${i}${j}`);
                     td.css({
                    "width": this.tdWidth,
                    "height":this.tdHeight,
                    "background-image":`url(${this.url})`,
                    "background-position": `${-j*this.tdWidth}px ${-i*this.tdHeight}px`


                });

                }else{
                    //mettre la derniere case comme case vide
                    td.addClass("vide");
                    td.css({
                    "width":this.tdWidth,
                    "height":this.tdHeight,
                    "background-color":this.couleurImageVide

                });
                }
                span.html(ordreDesCase);
                td.append(span);
                tr.append(td);
              }
                table.append(tr);

          }

            this.$grid.html(table);
            this.taille=ordreDesCase;




        },






    }






jeu.init();
});
